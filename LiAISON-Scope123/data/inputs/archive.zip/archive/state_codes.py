state_codes = [
    "AL", "AK", "AZ", "AR", "CA", "CO", "CT", "DE", "FL", "GA", 
    "HI", "ID", "IL", "IN", "IA", "KS", "KY", "LA", "ME", "MD", 
    "MA", "MI", "MN", "MS", "MO", "MT", "NE", "NV", "NH", "NJ", 
    "NM", "NY", "NC", "ND", "OH", "OK", "OR", "PA", "RI", "SC", 
    "SD", "TN", "TX", "UT", "VT", "VA", "WA", "WV", "WI", "WY", 
    "DC", "AS", "GU", "MP", "PR", "VI"
]


import pandas as pd

df = pd.read_csv('modification_inventory.csv')

total_df = pd.DataFrame()
for st in state_codes:
    df['process_location'] = st
    df['supplying_location'] = st

    total_df = pd.concat([total_df,df])

total_df.to_csv('modification_inventory2.csv', index=False)

